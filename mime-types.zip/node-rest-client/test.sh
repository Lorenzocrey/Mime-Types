#!/bin/sh
npm test